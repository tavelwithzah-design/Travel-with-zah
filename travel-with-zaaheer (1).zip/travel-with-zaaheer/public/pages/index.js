import { getSortedPostsData } from '../lib/posts'
import PostCard from '../components/PostCard'
import SEO from '../components/SEO'
import Link from 'next/link'
import styles from './index.module.css'

export default function Home({ featuredPost, recentPosts, secondaryPosts }) {
  return (
    <>
      <SEO
        title="Luxury Travel Stories & Destination Guides"
        description="Travel With Zaaheer — Curating extraordinary journeys across the world's most remarkable destinations. Luxury travel stories, guides, and cinematic photography."
        url="/"
      />

      {/* ===== HERO SECTION ===== */}
      <section className={styles.hero}>
        {featuredPost ? (
          <div className={styles.heroInner}>
            <Link href={`/blog/${featuredPost.slug}`} className={styles.heroImageLink} aria-label={featuredPost.title}>
              <div className={styles.heroImageWrap}>
                {featuredPost.featuredImage ? (
                  <img
                    src={featuredPost.featuredImage}
                    alt={featuredPost.featuredImageAlt || featuredPost.title}
                    className={styles.heroImage}
                    priority="true"
                  />
                ) : (
                  <div className={styles.heroImagePlaceholder}>
                    <div className={styles.heroPlaceholderInner}>
                      <span className={styles.heroOrnament}>✦</span>
                      <p>Your Featured Story Awaits</p>
                    </div>
                  </div>
                )}
                <div className={styles.heroGradient}></div>
              </div>
            </Link>
            <div className={styles.heroContent}>
              <span className={styles.heroLabel}>Featured Story</span>
              <Link href={`/blog/${featuredPost.slug}`} className={styles.heroTitleLink}>
                <h1 className={styles.heroTitle}>{featuredPost.title}</h1>
              </Link>
              <div className={styles.heroDivider}></div>
              {featuredPost.excerpt && (
                <p className={styles.heroExcerpt}>{featuredPost.excerpt}</p>
              )}
              <Link href={`/blog/${featuredPost.slug}`} className={styles.heroBtn}>
                Read the Story <span className={styles.heroArrow}>→</span>
              </Link>
            </div>
          </div>
        ) : (
          <div className={styles.heroEmpty}>
            <div className={styles.heroEmptyContent}>
              <span className={styles.heroLabel}>Welcome</span>
              <h1 className={styles.heroTitle}>Travel With Zaaheer</h1>
              <div className={styles.heroDivider}></div>
              <p className={styles.heroExcerpt}>
                Extraordinary journeys. Cinematic storytelling. The world's finest destinations.
              </p>
              <Link href="/admin" className={styles.heroBtn}>
                Start Writing <span className={styles.heroArrow}>→</span>
              </Link>
            </div>
          </div>
        )}
      </section>

      {/* ===== INTRO STRIP ===== */}
      <section className={styles.introStrip}>
        <div className={styles.container}>
          <div className={styles.introInner}>
            <div className={styles.introLine}></div>
            <p className={styles.introText}>
              Luxury travel stories · Destination guides · Cinematic photography
            </p>
            <div className={styles.introLine}></div>
          </div>
        </div>
      </section>

      {/* ===== FEATURED SECTION (big featured card) ===== */}
      {featuredPost && (
        <section className={styles.featuredSection}>
          <div className={styles.container}>
            <div className={styles.sectionHeader}>
              <span className={styles.sectionLabel}>Editor's Pick</span>
              <h2 className={styles.sectionTitle}>Featured Journey</h2>
              <div className={styles.goldLine}></div>
            </div>
            <PostCard post={featuredPost} featured={true} />
          </div>
        </section>
      )}

      {/* ===== RECENT POSTS GRID ===== */}
      {recentPosts.length > 0 && (
        <section className={styles.postsSection}>
          <div className={styles.container}>
            <div className={styles.sectionHeader}>
              <span className={styles.sectionLabel}>Latest Stories</span>
              <h2 className={styles.sectionTitle}>Recent Journeys</h2>
              <div className={styles.goldLine}></div>
            </div>
            <div className={styles.postsGrid}>
              {recentPosts.map((post, i) => (
                <PostCard
                  key={post.slug}
                  post={post}
                  size={i === 0 ? 'large' : 'normal'}
                />
              ))}
            </div>
            <div className={styles.viewAllWrap}>
              <Link href="/blog" className={styles.viewAll}>
                View All Stories <span>→</span>
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* ===== CATEGORY STRIP ===== */}
      <section className={styles.categoryStrip}>
        <div className={styles.container}>
          <div className={styles.sectionHeader}>
            <span className={styles.sectionLabel}>Explore</span>
            <h2 className={styles.sectionTitle}>Journey by Category</h2>
            <div className={styles.goldLine}></div>
          </div>
          <div className={styles.categoryGrid}>
            {[
              { slug: 'destinations', label: 'Destinations', emoji: '🌍' },
              { slug: 'luxury-stays', label: 'Luxury Stays', emoji: '🏨' },
              { slug: 'adventure', label: 'Adventure', emoji: '🏔️' },
              { slug: 'culture-food', label: 'Culture & Food', emoji: '🍜' },
              { slug: 'travel-tips', label: 'Travel Tips', emoji: '✈️' },
              { slug: 'photography', label: 'Photography', emoji: '📷' },
            ].map(cat => (
              <Link key={cat.slug} href={`/category/${cat.slug}`} className={styles.catCard}>
                <span className={styles.catEmoji}>{cat.emoji}</span>
                <span className={styles.catLabel}>{cat.label}</span>
                <span className={styles.catArrow}>→</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ===== SECONDARY POSTS ===== */}
      {secondaryPosts.length > 0 && (
        <section className={styles.secondarySection}>
          <div className={styles.container}>
            <div className={styles.sectionHeader}>
              <span className={styles.sectionLabel}>More to Discover</span>
              <h2 className={styles.sectionTitle}>Keep Exploring</h2>
              <div className={styles.goldLine}></div>
            </div>
            <div className={styles.secondaryGrid}>
              {secondaryPosts.map(post => (
                <PostCard key={post.slug} post={post} size="normal" />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ===== QUOTE SECTION ===== */}
      <section className={styles.quoteSection}>
        <div className={styles.container}>
          <div className={styles.quoteInner}>
            <div className={styles.quoteOrnament}>✦</div>
            <blockquote className={styles.quoteText}>
              "Not all those who wander are lost — some are simply looking for the next extraordinary story."
            </blockquote>
            <div className={styles.quoteAuthor}>— Zaaheer</div>
          </div>
        </div>
      </section>
    </>
  )
}

export async function getStaticProps() {
  const allPosts = getSortedPostsData()

  const featuredPost = allPosts.length > 0 ? allPosts[0] : null
  const recentPosts = allPosts.slice(1, 7) // Up to 6 recent posts
  const secondaryPosts = allPosts.slice(7, 13) // Up to 6 more

  return {
    props: {
      featuredPost,
      recentPosts,
      secondaryPosts,
    },
  }
}
