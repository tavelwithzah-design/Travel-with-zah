import { getSortedPostsData } from '../../lib/posts'
import PostCard from '../../components/PostCard'
import SEO from '../../components/SEO'
import Link from 'next/link'
import styles from '../blog.module.css'

const POSTS_PER_PAGE = 9

export default function BlogPage({ posts, totalPages, currentPage }) {
  return (
    <>
      <SEO
        title={`All Stories${currentPage > 1 ? ` — Page ${currentPage}` : ''}`}
        description="Browse all travel stories, destination guides, and luxury travel experiences from Travel With Zaaheer."
        url={currentPage > 1 ? `/page/${currentPage}` : '/blog'}
      />

      {/* Page Hero */}
      <section className={styles.pageHero}>
        <div className={styles.container}>
          <span className={styles.heroLabel}>The Journal</span>
          <h1 className={styles.heroTitle}>All Stories</h1>
          <div className={styles.heroDivider}></div>
          <p className={styles.heroSubtitle}>
            Every destination has a story. Discover them all.
          </p>
        </div>
      </section>

      {/* Posts Grid */}
      <section className={styles.postsSection}>
        <div className={styles.container}>
          {posts.length > 0 ? (
            <>
              <div className={styles.postsGrid}>
                {posts.map((post, i) => (
                  <PostCard
                    key={post.slug}
                    post={post}
                    size={i === 0 && currentPage === 1 ? 'large' : 'normal'}
                  />
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <nav className={styles.pagination} aria-label="Pagination">
                  {currentPage > 1 && (
                    <Link
                      href={currentPage === 2 ? '/blog' : `/page/${currentPage - 1}`}
                      className={styles.pageBtn}
                    >
                      ← Previous
                    </Link>
                  )}

                  <div className={styles.pageNumbers}>
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map(num => (
                      <Link
                        key={num}
                        href={num === 1 ? '/blog' : `/page/${num}`}
                        className={`${styles.pageNum} ${num === currentPage ? styles.pageNumActive : ''}`}
                      >
                        {num}
                      </Link>
                    ))}
                  </div>

                  {currentPage < totalPages && (
                    <Link href={`/page/${currentPage + 1}`} className={styles.pageBtn}>
                      Next →
                    </Link>
                  )}
                </nav>
              )}
            </>
          ) : (
            <div className={styles.empty}>
              <span className={styles.emptyOrnament}>✦</span>
              <h2>Stories Coming Soon</h2>
              <p>New adventures are being written. Check back soon.</p>
              <Link href="/admin" className={styles.adminLink}>
                Add Your First Post →
              </Link>
            </div>
          )}
        </div>
      </section>
    </>
  )
}

export async function getStaticProps({ params }) {
  const page = params?.page ? parseInt(params.page) : 1
  const allPosts = getSortedPostsData()
  const totalPages = Math.ceil(allPosts.length / POSTS_PER_PAGE)
  const offset = (page - 1) * POSTS_PER_PAGE
  const posts = allPosts.slice(offset, offset + POSTS_PER_PAGE)

  return {
    props: {
      posts,
      totalPages,
      currentPage: page,
    },
  }
}

export async function getStaticPaths() {
  const allPosts = getSortedPostsData()
  const totalPages = Math.ceil(allPosts.length / POSTS_PER_PAGE)

  const paths = Array.from({ length: totalPages }, (_, i) => ({
    params: { page: String(i + 1) },
  }))

  return {
    paths,
    fallback: false,
  }
}
