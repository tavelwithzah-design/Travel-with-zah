import { getSortedPostsData } from '../lib/posts'
import PostCard from '../components/PostCard'
import SEO from '../components/SEO'
import Link from 'next/link'
import styles from './blog.module.css'

const POSTS_PER_PAGE = 9

export default function Blog({ posts, totalPages }) {
  return (
    <>
      <SEO
        title="All Stories"
        description="Browse all travel stories, destination guides, and luxury travel experiences from Travel With Zaaheer."
        url="/blog"
      />

      <section className={styles.pageHero}>
        <div className={styles.container}>
          <span className={styles.heroLabel}>The Journal</span>
          <h1 className={styles.heroTitle}>All Stories</h1>
          <div className={styles.heroDivider}></div>
          <p className={styles.heroSubtitle}>Every destination has a story. Discover them all.</p>
        </div>
      </section>

      <section className={styles.postsSection}>
        <div className={styles.container}>
          {posts.length > 0 ? (
            <>
              <div className={styles.postsGrid}>
                {posts.map((post, i) => (
                  <PostCard
                    key={post.slug}
                    post={post}
                    size={i === 0 ? 'large' : 'normal'}
                  />
                ))}
              </div>

              {totalPages > 1 && (
                <nav className={styles.pagination} aria-label="Pagination">
                  <div className={styles.pageNumbers}>
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map(num => (
                      <Link
                        key={num}
                        href={num === 1 ? '/blog' : `/page/${num}`}
                        className={`${styles.pageNum} ${num === 1 ? styles.pageNumActive : ''}`}
                      >
                        {num}
                      </Link>
                    ))}
                  </div>
                  {totalPages > 1 && (
                    <Link href="/page/2" className={styles.pageBtn}>
                      Next →
                    </Link>
                  )}
                </nav>
              )}
            </>
          ) : (
            <div className={styles.empty}>
              <span className={styles.emptyOrnament}>✦</span>
              <h2>Stories Coming Soon</h2>
              <p>New adventures are being written. Check back soon.</p>
              <Link href="/admin" className={styles.adminLink}>Add Your First Post →</Link>
            </div>
          )}
        </div>
      </section>
    </>
  )
}

export async function getStaticProps() {
  const allPosts = getSortedPostsData()
  const totalPages = Math.ceil(allPosts.length / POSTS_PER_PAGE)
  const posts = allPosts.slice(0, POSTS_PER_PAGE)

  return {
    props: { posts, totalPages },
  }
}
