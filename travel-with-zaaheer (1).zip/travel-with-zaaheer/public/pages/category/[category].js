import { getSortedPostsData, formatCategoryName } from '../../lib/posts'
import PostCard from '../../components/PostCard'
import SEO from '../../components/SEO'
import Link from 'next/link'
import styles from '../blog.module.css'
import catStyles from './[category].module.css'

const CATEGORIES = [
  'destinations',
  'travel-tips',
  'luxury-stays',
  'adventure',
  'culture-food',
  'photography',
]

const CATEGORY_DESCRIPTIONS = {
  destinations: 'Extraordinary places around the world — from hidden gems to iconic landmarks.',
  'travel-tips': 'Practical wisdom and insider knowledge to elevate every journey.',
  'luxury-stays': 'The world\'s most remarkable hotels, resorts, and retreats.',
  adventure: 'Heart-racing experiences and breathtaking wild escapes.',
  'culture-food': 'The soul of every destination — its people, traditions, and flavors.',
  photography: 'Capturing the world\'s most cinematic moments through the lens.',
}

export default function CategoryPage({ posts, category, categoryName }) {
  return (
    <>
      <SEO
        title={categoryName}
        description={CATEGORY_DESCRIPTIONS[category] || `Explore our ${categoryName} stories.`}
        url={`/category/${category}`}
      />

      <section className={catStyles.categoryHero}>
        <div className={styles.container}>
          <Link href="/blog" className={catStyles.backCrumb}>← All Stories</Link>
          <span className={catStyles.heroLabel}>Category</span>
          <h1 className={catStyles.heroTitle}>{categoryName}</h1>
          <div className={catStyles.heroDivider}></div>
          {CATEGORY_DESCRIPTIONS[category] && (
            <p className={catStyles.heroDesc}>{CATEGORY_DESCRIPTIONS[category]}</p>
          )}
          <span className={catStyles.postCount}>{posts.length} {posts.length === 1 ? 'Story' : 'Stories'}</span>
        </div>
      </section>

      <section className={styles.postsSection}>
        <div className={styles.container}>
          {posts.length > 0 ? (
            <div className={styles.postsGrid}>
              {posts.map(post => (
                <PostCard key={post.slug} post={post} />
              ))}
            </div>
          ) : (
            <div className={styles.empty}>
              <span className={styles.emptyOrnament}>✦</span>
              <h2>No Stories Yet</h2>
              <p>Stories in {categoryName} are coming soon.</p>
              <Link href="/blog" className={styles.adminLink}>← Browse All Stories</Link>
            </div>
          )}
        </div>
      </section>

      {/* Other categories */}
      <section className={catStyles.otherCats}>
        <div className={styles.container}>
          <div className={catStyles.otherCatsInner}>
            <span className={catStyles.otherCatsLabel}>Explore More</span>
            <div className={catStyles.catLinks}>
              {CATEGORIES.filter(c => c !== category).map(c => (
                <Link key={c} href={`/category/${c}`} className={catStyles.catLink}>
                  {formatCategoryName(c)}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export async function getStaticProps({ params }) {
  const { category } = params
  const posts = getSortedPostsData({ category })
  const categoryName = formatCategoryName(category)

  return {
    props: {
      posts,
      category,
      categoryName,
    },
  }
}

export async function getStaticPaths() {
  return {
    paths: CATEGORIES.map(category => ({ params: { category } })),
    fallback: false,
  }
}
