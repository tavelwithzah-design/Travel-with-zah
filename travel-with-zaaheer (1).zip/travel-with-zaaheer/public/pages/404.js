import Link from 'next/link'
import SEO from '../components/SEO'
import styles from './404.module.css'

export default function NotFound() {
  return (
    <>
      <SEO
        title="Page Not Found"
        description="The page you're looking for doesn't exist."
      />
      <section className={styles.notFound}>
        <div className={styles.inner}>
          <span className={styles.ornament}>✦</span>
          <span className={styles.code}>404</span>
          <h1 className={styles.title}>Lost in Transit</h1>
          <div className={styles.divider}></div>
          <p className={styles.text}>
            The page you're looking for seems to have wandered off the beaten path.
          </p>
          <Link href="/" className={styles.homeBtn}>
            Return Home <span>→</span>
          </Link>
        </div>
      </section>
    </>
  )
}
