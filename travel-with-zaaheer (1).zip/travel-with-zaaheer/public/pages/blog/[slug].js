import { getAllPostSlugs, getPostData, getSortedPostsData, formatDate, getVideoEmbed, formatCategoryName } from '../../lib/posts'
import SEO from '../../components/SEO'
import PostCard from '../../components/PostCard'
import Link from 'next/link'
import { useEffect, useState } from 'react'
import styles from './[slug].module.css'

export default function BlogPost({ post, relatedPosts, allPosts }) {
  const [readProgress, setReadProgress] = useState(0)

  useEffect(() => {
    const updateProgress = () => {
      const scrollTop = window.scrollY
      const docHeight = document.documentElement.scrollHeight - window.innerHeight
      const progress = docHeight > 0 ? scrollTop / docHeight : 0
      setReadProgress(progress)
    }
    window.addEventListener('scroll', updateProgress)
    return () => window.removeEventListener('scroll', updateProgress)
  }, [])

  if (!post) return null

  const videoEmbed = getVideoEmbed(post.videoUrl)

  // Auto internal links: find mentions of other posts in content
  const internalLinks = allPosts
    .filter(p => p.slug !== post.slug)
    .slice(0, 3)

  return (
    <>
      <SEO
        title={post.metaTitle || post.title}
        description={post.metaDescription || post.excerpt}
        image={post.featuredImage}
        url={`/blog/${post.slug}`}
        type="article"
        publishedTime={post.date}
        author={post.author}
      />

      {/* Reading Progress Bar */}
      <div
        className={styles.progressBar}
        style={{ transform: `scaleX(${readProgress})` }}
        role="progressbar"
        aria-label="Reading progress"
      />

      {/* Hero Image */}
      <div className={styles.postHero}>
        {post.featuredImage ? (
          <img
            src={post.featuredImage}
            alt={post.featuredImageAlt || post.title}
            className={styles.heroImg}
          />
        ) : (
          <div className={styles.heroPlaceholder}>
            <span>✦</span>
          </div>
        )}
        <div className={styles.heroOverlay}></div>
      </div>

      {/* Post Content */}
      <article className={styles.article}>
        <div className={styles.container}>

          {/* Header */}
          <header className={styles.postHeader}>
            <div className={styles.postMeta}>
              {post.category && (
                <Link href={`/category/${post.category}`} className={styles.categoryBadge}>
                  {formatCategoryName(post.category)}
                </Link>
              )}
              <span className={styles.metaDivider}>·</span>
              <span className={styles.readTime}>{post.readTime} min read</span>
              <span className={styles.metaDivider}>·</span>
              <time dateTime={post.date} className={styles.date}>
                {formatDate(post.date)}
              </time>
            </div>

            <h1 className={styles.postTitle}>{post.title}</h1>

            <div className={styles.titleDivider}></div>

            {post.excerpt && (
              <p className={styles.postExcerpt}>{post.excerpt}</p>
            )}

            {/* Tags */}
            {post.tags && post.tags.length > 0 && (
              <div className={styles.tags}>
                {post.tags.map(tag => (
                  <span key={tag} className={styles.tag}>{tag}</span>
                ))}
              </div>
            )}
          </header>

          {/* Main Content */}
          <div className={styles.postLayout}>
            {/* Article Body */}
            <div className={styles.postBody}>
              {/* Video Embed */}
              {videoEmbed && (
                <div className={styles.videoWrap}>
                  <iframe
                    src={videoEmbed.embedUrl}
                    title={`Video for ${post.title}`}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className={styles.videoFrame}
                    loading="lazy"
                  />
                </div>
              )}

              {/* Markdown Content */}
              <div
                className={styles.content}
                dangerouslySetInnerHTML={{ __html: post.contentHtml }}
              />

              {/* Auto Internal Links Block */}
              {internalLinks.length > 0 && (
                <aside className={styles.internalLinks}>
                  <div className={styles.internalLinksHeader}>
                    <span className={styles.internalLinksLabel}>Continue Reading</span>
                  </div>
                  <ul className={styles.internalLinksList}>
                    {internalLinks.map(p => (
                      <li key={p.slug}>
                        <Link href={`/blog/${p.slug}`} className={styles.internalLink}>
                          <span className={styles.internalLinkArrow}>→</span>
                          {p.title}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </aside>
              )}
            </div>

            {/* Sidebar */}
            <aside className={styles.sidebar}>
              {/* Author Card */}
              <div className={styles.authorCard}>
                <div className={styles.authorPhotoWrap}>
                  {post.authorPhoto ? (
                    <img
                      src={post.authorPhoto}
                      alt={post.author || 'Zaaheer'}
                      className={styles.authorPhoto}
                    />
                  ) : (
                    <div className={styles.authorInitial}>
                      {(post.author || 'Z').charAt(0)}
                    </div>
                  )}
                </div>
                <div className={styles.authorInfo}>
                  <span className={styles.authorLabel}>Written by</span>
                  <strong className={styles.authorName}>{post.author || 'Zaaheer'}</strong>
                  <div className={styles.authorGoldLine}></div>
                  {post.authorBio && (
                    <p className={styles.authorBio}>{post.authorBio}</p>
                  )}
                </div>
              </div>

              {/* Categories */}
              <div className={styles.sidebarCard}>
                <h3 className={styles.sidebarTitle}>Explore More</h3>
                <div className={styles.sidebarLinks}>
                  {[
                    { slug: 'destinations', label: 'Destinations' },
                    { slug: 'luxury-stays', label: 'Luxury Stays' },
                    { slug: 'adventure', label: 'Adventure' },
                    { slug: 'culture-food', label: 'Culture & Food' },
                    { slug: 'travel-tips', label: 'Travel Tips' },
                  ].map(cat => (
                    <Link key={cat.slug} href={`/category/${cat.slug}`} className={styles.sidebarLink}>
                      {cat.label} <span>→</span>
                    </Link>
                  ))}
                </div>
              </div>
            </aside>
          </div>
        </div>
      </article>

      {/* Author Section (full width) */}
      <section className={styles.authorSection}>
        <div className={styles.container}>
          <div className={styles.authorFull}>
            <div className={styles.authorPhotoWrapLg}>
              {post.authorPhoto ? (
                <img src={post.authorPhoto} alt={post.author || 'Zaaheer'} className={styles.authorPhotoLg} />
              ) : (
                <div className={styles.authorInitialLg}>{(post.author || 'Z').charAt(0)}</div>
              )}
            </div>
            <div className={styles.authorDetails}>
              <span className={styles.authorLabel}>About the Author</span>
              <h3 className={styles.authorNameLg}>{post.author || 'Zaaheer'}</h3>
              <div className={styles.authorDivider}></div>
              {post.authorBio && <p className={styles.authorBioLg}>{post.authorBio}</p>}
            </div>
          </div>
        </div>
      </section>

      {/* Related Posts */}
      {relatedPosts.length > 0 && (
        <section className={styles.related}>
          <div className={styles.container}>
            <div className={styles.relatedHeader}>
              <span className={styles.relatedLabel}>More Stories</span>
              <h2 className={styles.relatedTitle}>You Might Also Enjoy</h2>
              <div className={styles.relatedDivider}></div>
            </div>
            <div className={styles.relatedGrid}>
              {relatedPosts.map(post => (
                <PostCard key={post.slug} post={post} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Back to Journal */}
      <div className={styles.backWrap}>
        <div className={styles.container}>
          <Link href="/blog" className={styles.backLink}>
            ← Back to All Stories
          </Link>
        </div>
      </div>
    </>
  )
}

export async function getStaticProps({ params }) {
  const post = await getPostData(params.slug)

  if (!post) {
    return { notFound: true }
  }

  // Get related posts (same category, exclude current)
  const relatedPosts = getSortedPostsData({
    category: post.category,
    excludeSlug: params.slug,
    limit: 3,
  })

  // If not enough related, fill with recent
  const allRecentPosts = getSortedPostsData({ excludeSlug: params.slug, limit: 6 })

  const finalRelated = relatedPosts.length >= 3
    ? relatedPosts
    : [...relatedPosts, ...allRecentPosts.filter(p => !relatedPosts.find(r => r.slug === p.slug))].slice(0, 3)

  // For auto internal links
  const allPosts = getSortedPostsData({ excludeSlug: params.slug, limit: 4 })

  return {
    props: {
      post,
      relatedPosts: finalRelated,
      allPosts,
    },
  }
}

export async function getStaticPaths() {
  const paths = getAllPostSlugs()
  return {
    paths,
    fallback: false,
  }
}
