/**
 * TRAVEL WITH ZAAHEER — posts-data.js
 * ------------------------------------
 * Central data store for all blog posts.
 * Admin edits via Decap CMS update the content/blog/*.md files.
 * For the static site, posts are also represented here for
 * the homepage grid and blog listing JS rendering.
 *
 * STRUCTURE: Each post object maps to a /content/blog/*.md file.
 */

const POSTS = [
  {
    id: "santorini-sunsets",
    slug: "santorini-sunsets",
    title: "The Last Light of Santorini",
    excerpt: "Where volcanic cliffs meet the infinite Aegean — a journey into Greece's most intoxicating island, told through its golden hours.",
    category: "Europe",
    tags: ["Greece", "Islands", "Luxury", "Sunsets"],
    date: "2025-06-12",
    dateFormatted: "June 12, 2025",
    author: "Zaaheer",
    readTime: "8 min read",
    image: "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?w=900&q=80&auto=format",
    imageAlt: "White-domed church overlooking the blue Aegean Sea at sunset in Santorini, Greece",
    url: "/pages/blog/santorini-sunsets.html",
    featured: true,
    size: "large"
  }
];

/**
 * Render post cards into a target grid element.
 * @param {string} containerId - ID of the grid container
 * @param {Object} options - { limit, size }
 */
function renderPostCards(containerId, options = {}) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const { limit = POSTS.length } = options;
  const posts = POSTS.slice(0, limit);

  const sizes = ["large", "medium", "small", "small", "small", "small"];

  container.innerHTML = posts.map((post, i) => {
    const size = post.size || sizes[i] || "small";
    return buildCard(post, size);
  }).join('');
}

function buildCard(post, size) {
  return `
    <article class="story-card story-card--${size} animate-in animate-in-${Math.min(4, size === 'large' ? 1 : size === 'medium' ? 2 : 3)}" 
             itemscope itemtype="https://schema.org/BlogPosting">
      <a href="${post.url}" class="card-image-link" tabindex="-1" aria-hidden="true">
        <img
          src="${post.image}"
          alt="${post.imageAlt}"
          class="card-img"
          loading="lazy"
          itemprop="image"
        />
      </a>
      <div class="card-body">
        <div class="card-meta">
          <a href="/pages/category/${post.category.toLowerCase().replace(/\s+/g,'-')}.html" class="card-category">${post.category}</a>
          <span class="card-read-time">${post.readTime}</span>
        </div>
        <h2 class="card-title" itemprop="headline">
          <a href="${post.url}">${post.title}</a>
        </h2>
        <p class="card-excerpt" itemprop="description">${post.excerpt}</p>
        <a href="${post.url}" class="card-cta" aria-label="Read full story: ${post.title}">
          Read story <span aria-hidden="true">→</span>
        </a>
      </div>
      <meta itemprop="author" content="${post.author}" />
      <meta itemprop="datePublished" content="${post.date}" />
    </article>
  `;
}

/**
 * Get posts by category
 */
function getPostsByCategory(category) {
  return POSTS.filter(p => p.category.toLowerCase() === category.toLowerCase());
}

/**
 * Get related posts (exclude current, same category first)
 */
function getRelatedPosts(currentSlug, limit = 3) {
  const current = POSTS.find(p => p.slug === currentSlug);
  if (!current) return POSTS.slice(0, limit);
  const sameCategory = POSTS.filter(p => p.slug !== currentSlug && p.category === current.category);
  const others = POSTS.filter(p => p.slug !== currentSlug && p.category !== current.category);
  return [...sameCategory, ...others].slice(0, limit);
}
