/**
 * TRAVEL WITH ZAAHEER — main.js
 * --------------------------------
 * Site-wide JavaScript: header, mobile menu, animations, dynamic rendering
 */

document.addEventListener('DOMContentLoaded', function () {

  // ---- Footer year ----
  const yearEl = document.getElementById('footer-year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // ---- Sticky header scroll effect ----
  const header = document.getElementById('site-header');
  if (header) {
    const onScroll = () => {
      header.classList.toggle('scrolled', window.scrollY > 40);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  // ---- Mobile menu ----
  const mobileBtn  = document.getElementById('mobileMenuBtn');
  const mobileMenu = document.getElementById('mobileMenu');

  if (mobileBtn && mobileMenu) {
    mobileBtn.addEventListener('click', function () {
      const open = mobileMenu.classList.toggle('open');
      mobileBtn.classList.toggle('active', open);
      mobileBtn.setAttribute('aria-expanded', String(open));
      mobileMenu.setAttribute('aria-hidden', String(!open));
    });

    // Close on outside click
    document.addEventListener('click', function (e) {
      if (!header.contains(e.target) && mobileMenu.classList.contains('open')) {
        mobileMenu.classList.remove('open');
        mobileBtn.classList.remove('active');
        mobileBtn.setAttribute('aria-expanded', 'false');
        mobileMenu.setAttribute('aria-hidden', 'true');
      }
    });

    // Close on Escape
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && mobileMenu.classList.contains('open')) {
        mobileMenu.classList.remove('open');
        mobileBtn.classList.remove('active');
        mobileBtn.setAttribute('aria-expanded', 'false');
        mobileMenu.setAttribute('aria-hidden', 'true');
        mobileBtn.focus();
      }
    });
  }

  // ---- Render homepage stories grid ----
  if (document.getElementById('stories-grid') && typeof renderPostCards === 'function') {
    renderPostCards('stories-grid', { limit: 6 });
  }

  // ---- Render blog listing grid ----
  if (document.getElementById('blog-listing-grid') && typeof renderPostCards === 'function') {
    renderPostCards('blog-listing-grid');
  }

  // ---- Render related posts ----
  const relatedGrid = document.getElementById('related-posts-grid');
  if (relatedGrid && typeof getRelatedPosts === 'function') {
    const slug = relatedGrid.dataset.currentSlug || '';
    const related = getRelatedPosts(slug, 3);
    relatedGrid.innerHTML = related.map(p => buildCard ? buildCard(p, 'small') : '').join('');
  }

  // ---- Intersection Observer: fade-in animations ----
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.animationPlayState = 'running';
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });

    document.querySelectorAll('.animate-in').forEach(el => {
      el.style.animationPlayState = 'paused';
      observer.observe(el);
    });
  }

  // ---- Newsletter form ----
  const newsletterForm = document.querySelector('.newsletter-form');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', function (e) {
      const btn = this.querySelector('.newsletter-btn');
      if (btn) {
        btn.textContent = 'Subscribing…';
        btn.disabled = true;
        setTimeout(() => {
          btn.textContent = 'Subscribed ✓';
        }, 2000);
      }
    });
  }

  // ---- Video embed conversion ----
  // Converts YouTube/Vimeo links in post body to embedded iframes
  convertVideoLinks();

  // ---- Active nav link ----
  highlightActiveNav();

});

/**
 * Convert YouTube/Vimeo URLs in .video-embed-placeholder spans to iframes.
 * The CMS stores the raw URL; this function converts it client-side.
 */
function convertVideoLinks() {
  document.querySelectorAll('.video-embed-placeholder').forEach(el => {
    const url = el.dataset.url || el.textContent.trim();
    const embedUrl = getEmbedUrl(url);
    if (embedUrl) {
      const wrap = document.createElement('div');
      wrap.className = 'video-wrap';
      wrap.innerHTML = `<iframe src="${embedUrl}" title="Video" allowfullscreen loading="lazy"></iframe>`;
      el.replaceWith(wrap);
    }
  });
}

function getEmbedUrl(url) {
  if (!url) return null;
  // YouTube
  const ytMatch = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
  if (ytMatch) return `https://www.youtube.com/embed/${ytMatch[1]}?rel=0`;
  // Vimeo
  const vmMatch = url.match(/vimeo\.com\/(\d+)/);
  if (vmMatch) return `https://player.vimeo.com/video/${vmMatch[1]}?dnt=1`;
  return null;
}

/**
 * Mark the currently active navigation link.
 */
function highlightActiveNav() {
  const path = window.location.pathname;
  document.querySelectorAll('.header-nav a, .footer-nav a').forEach(link => {
    const href = link.getAttribute('href');
    if (href && path.endsWith(href)) {
      link.style.color = 'var(--color-gold)';
    }
  });
}
