# Travel With Zaaheer — Deployment Guide

## 🚀 Deploy to Netlify in 10 Minutes

This is a complete static website with Decap CMS (Netlify CMS) for admin content management.
No technical knowledge required after initial setup.

---

## STEP 1 — Create a GitHub Account
1. Go to https://github.com and sign up (free)
2. Remember your username — you'll need it in Step 3

---

## STEP 2 — Upload This Project to GitHub

### Option A: GitHub Desktop (Easiest for Beginners)
1. Download GitHub Desktop from https://desktop.github.com
2. Sign in with your GitHub account
3. Click **File → Add Local Repository**
4. Select the `travel-with-zaaheer` folder
5. Click **Publish Repository**
6. Give it the name: `travel-with-zaaheer`
7. Uncheck "Keep this code private" (or keep it — both work)
8. Click **Publish Repository**

### Option B: GitHub.com (No Downloads)
1. Go to https://github.com/new
2. Repository name: `travel-with-zaaheer`
3. Click **Create repository**
4. Click **uploading an existing file**
5. Drag and drop the entire `public/` folder contents
6. Commit the files

---

## STEP 3 — Deploy on Netlify

1. Go to https://netlify.com and sign up with your GitHub account
2. Click **"Add new site" → "Import an existing project"**
3. Choose **GitHub**
4. Select your `travel-with-zaaheer` repository
5. In Build settings:
   - **Build command:** Leave EMPTY (no build needed)
   - **Publish directory:** `public`
6. Click **"Deploy site"**

Your site will be live in about 30 seconds! 🎉

---

## STEP 4 — Set Up the Admin Panel (Decap CMS)

### 4a. Enable Netlify Identity
1. In your Netlify dashboard, go to **Site Settings → Identity**
2. Click **"Enable Identity"**
3. Under **Registration**, select **"Invite only"**

### 4b. Enable Git Gateway
1. Still in Identity settings, scroll to **Services**
2. Click **"Enable Git Gateway"**
3. This connects the CMS to your GitHub repository

### 4c. Invite Yourself as Admin
1. In Identity settings, click **"Invite users"**
2. Enter your email address
3. You'll receive an email — click the link to set your password
4. ✅ You can now log in at: `https://yoursite.netlify.app/admin/`

---

## STEP 5 — Custom Domain (Optional but Recommended)

1. Buy a domain (e.g. `travelwithzaaheer.com`) from Namecheap or GoDaddy
2. In Netlify: **Site Settings → Domain management → Add custom domain**
3. Follow Netlify's instructions to point your domain's nameservers
4. Netlify handles SSL/HTTPS automatically (free)

---

## STEP 6 — Update Config Files

### Update the admin config
In `/public/admin/config.yml`, update these TWO lines:
```yaml
site_url: https://YOUR-ACTUAL-DOMAIN.com
display_url: https://YOUR-ACTUAL-DOMAIN.com
```

### Update sitemap.xml
In `/public/sitemap.xml`, replace all instances of `travelwithzaaheer.com` with your actual domain.

### Update Open Graph URLs
In each `.html` file, find `og:url` meta tags and update to your domain.

---

## HOW TO CREATE A NEW BLOG POST

1. Go to `https://yoursite.netlify.app/admin/`
2. Log in with the email/password you set up
3. Click **"Blog Posts" → "New Blog Post"**
4. Fill in:
   - **Title** — Your post title
   - **Publish Date** — When it was written
   - **Status** — Toggle OFF "Draft" to publish
   - **SEO** — Meta title and description (very important!)
   - **Featured Image** — Upload your hero photo
   - **Image Alt Text** — Describe the image
   - **Category** — Select from dropdown
   - **Tags** — Add comma-separated tags
   - **Excerpt** — 2-3 sentence teaser for the homepage
   - **Video URL** — Paste a YouTube or Vimeo link (optional)
   - **Post Body** — Write your full article here
5. Click **"Save" → "Publish"**

The post will appear on your site within 1-2 minutes.

---

## HOW TO EDIT AN EXISTING POST

1. Go to `/admin/`
2. Click **"Blog Posts"**
3. Click the post you want to edit
4. Make changes and click **Save**

---

## NEWSLETTER SETUP (Formspree — Free)

1. Go to https://formspree.io and sign up
2. Create a new form
3. Copy your Form ID (looks like `xyzabcde`)
4. In `public/index.html`, find this line:
   ```
   action="https://formspree.io/f/YOUR_ID"
   ```
   Replace `YOUR_ID` with your actual form ID
5. Do the same in `public/pages/contact.html`

---

## FILE STRUCTURE

```
travel-with-zaaheer/
├── public/                     ← Netlify serves this folder
│   ├── index.html              ← Homepage
│   ├── admin/
│   │   ├── index.html          ← Decap CMS admin panel
│   │   └── config.yml          ← CMS configuration (edit this!)
│   ├── pages/
│   │   ├── blog.html           ← Blog listing page
│   │   ├── about.html          ← About page
│   │   ├── contact.html        ← Contact page
│   │   ├── destinations.html   ← Destinations page
│   │   └── blog/
│   │       └── santorini-sunsets.html  ← Sample blog post
│   ├── content/
│   │   └── blog/
│   │       └── santorini-sunsets.md    ← Sample post (markdown)
│   ├── styles/
│   │   └── main.css            ← All site styles (DO NOT EDIT)
│   ├── scripts/
│   │   ├── main.js             ← Site functionality (DO NOT EDIT)
│   │   └── posts-data.js       ← Post data for homepage grid
│   ├── sitemap.xml             ← SEO sitemap (update domain!)
│   ├── robots.txt              ← Search engine instructions
│   └── _redirects              ← Netlify URL redirects
├── netlify.toml                ← Netlify build configuration
└── DEPLOYMENT.md               ← This file
```

---

## ADDING NEW BLOG POSTS (Technical — for developer)

When you add posts via the CMS, Decap creates `.md` files in `content/blog/`.
The homepage grid is powered by `scripts/posts-data.js`.

To add a new post to the homepage grid, add a new object to the `POSTS` array in `posts-data.js`:

```js
{
  id: "my-new-post",
  slug: "my-new-post",
  title: "My Post Title",
  excerpt: "Short teaser text...",
  category: "Europe",
  tags: ["Italy", "Luxury"],
  date: "2025-08-01",
  dateFormatted: "August 1, 2025",
  author: "Zaaheer",
  readTime: "6 min read",
  image: "https://...",
  imageAlt: "Description of image",
  url: "/pages/blog/my-new-post.html",
  featured: false,
  size: "small"
}
```

Then create the matching `pages/blog/my-new-post.html` file.

---

## SUPPORT & MAINTENANCE

- **Netlify Docs:** https://docs.netlify.com
- **Decap CMS Docs:** https://decapcms.org/docs/
- **Formspree (forms):** https://formspree.io

---

## ZERO COST CHECKLIST
- ✅ GitHub (free)
- ✅ Netlify (free — 100GB bandwidth/month)
- ✅ Decap CMS (free)
- ✅ Netlify Identity (free — up to 1,000 users)
- ✅ SSL Certificate (free via Netlify)
- ✅ Formspree (free — 50 submissions/month)
- 💳 Domain name only: ~$10–15/year (travelwithzaaheer.com)

**Total monthly cost: $0**
