# Travel With Zaaheer — Complete Deployment Guide

## 🚀 Getting Your Site Live in 5 Steps

This guide will take you from zero to a live website in under 30 minutes.

---

## STEP 1: Create GitHub Repository

1. Go to **github.com** and sign in (or create a free account)
2. Click the **+** icon → **New repository**
3. Name it: `travel-with-zaaheer`
4. Set to **Public** (required for free Netlify deployment)
5. Click **Create repository**

Then upload all project files:
- Drag and drop all files into the repository
- OR use GitHub Desktop for easier uploading

---

## STEP 2: Deploy to Netlify

1. Go to **netlify.com** and sign in with your GitHub account
2. Click **Add new site** → **Import an existing project**
3. Choose **GitHub** → Select your `travel-with-zaaheer` repository
4. Netlify will auto-detect the settings from `netlify.toml`:
   - **Build command:** `npm run build`
   - **Publish directory:** `out`
5. Click **Deploy site**
6. Wait 2-3 minutes → Your site is live! ✅

---

## STEP 3: Enable Decap CMS (Admin Panel)

This allows you to add blog posts without touching code.

### 3a. Enable Netlify Identity
1. In Netlify dashboard → Go to your site
2. Click **Integrations** → Search for **Identity**
3. Click **Enable Identity**
4. Under **Registration**, select **Invite only** (important for security)

### 3b. Enable Git Gateway
1. Still in Identity settings
2. Click **Services** → **Enable Git Gateway**
3. This connects your CMS to GitHub

### 3c. Invite yourself as admin
1. Click **Invite users**
2. Enter your email address
3. Check your email → Click the invitation link
4. Set your password

### 3d. Access the Admin Panel
1. Visit: `https://your-site-name.netlify.app/admin`
2. Log in with your email and password
3. You now have a full content management system! 🎉

---

## STEP 4: Add a Custom Domain (Optional)

1. In Netlify: **Domain management** → **Add custom domain**
2. Enter your domain (e.g., `travelwithzaaheer.com`)
3. Update your domain's DNS settings to point to Netlify
4. Netlify automatically adds FREE SSL (HTTPS) ✅

---

## STEP 5: Publishing Your First Blog Post

1. Go to `/admin` on your site
2. Click **Blog Posts** → **New Blog Post**
3. Fill in:
   - **Title** — your post headline
   - **SEO Meta Description** — 150 characters for Google
   - **Featured Image** — upload a high-quality photo
   - **Excerpt** — 1-2 sentence summary
   - **Category** — select from dropdown
   - **Body** — write your full post
4. Toggle **Status** to **OFF** (Published)
5. Click **Publish** → Done! ✅

Your post will appear on the live site within 2 minutes.

---

## 📁 Project File Structure

```
travel-with-zaaheer/
│
├── admin/
│   ├── index.html          ← CMS admin page
│   └── config.yml          ← CMS configuration (DO NOT EDIT)
│
├── components/
│   ├── Header.js           ← Navigation
│   ├── Header.module.css
│   ├── Footer.js           ← Footer
│   ├── Footer.module.css
│   ├── PostCard.js         ← Blog post card component
│   ├── PostCard.module.css
│   └── SEO.js              ← SEO meta tags
│
├── content/
│   └── blog/               ← YOUR BLOG POSTS GO HERE
│       ├── santorini-at-sunset.md
│       ├── burj-al-arab-suite-review.md
│       └── ...
│
├── lib/
│   └── posts.js            ← Blog data processing
│
├── pages/
│   ├── _app.js             ← App wrapper
│   ├── _document.js        ← HTML document
│   ├── index.js            ← Homepage
│   ├── blog.js             ← All posts page
│   ├── 404.js              ← Error page
│   ├── blog/
│   │   └── [slug].js       ← Individual post page
│   ├── category/
│   │   └── [category].js   ← Category pages
│   └── page/
│       └── [page].js       ← Pagination pages
│
├── public/
│   └── images/
│       └── uploads/        ← Uploaded images stored here
│
├── styles/
│   └── globals.css         ← Global design system
│
├── netlify.toml            ← Netlify configuration
├── next.config.js          ← Next.js configuration
└── package.json            ← Dependencies
```

---

## 🎨 Understanding Your Design System

Your site uses three carefully chosen fonts:
- **Playfair Display** — Headlines and titles (elegant, editorial)
- **Cormorant Garamond** — Excerpts and quotes (refined, literary)
- **Jost** — Body text and navigation (modern, clean)

Colours:
- `#FAFAF8` — Background (warm white)
- `#1A1A18` — Primary text (deep charcoal)
- `#C9A96E` — Gold accent (luxury highlight)
- `#A07B3D` — Gold dark (interactive elements)

---

## ✍️ Writing Blog Posts in the CMS

### Image Guidelines
- **Resolution:** Minimum 1200 × 800px
- **Format:** JPEG or WebP preferred
- **File size:** Compress to under 500KB for fast loading
- **Alt text:** Always fill in for SEO and accessibility

### SEO Best Practices
- **Meta Description:** 140-160 characters, include your main keyword
- **Title:** Clear, descriptive, under 60 characters
- **Excerpt:** Write this as your "hook" — it appears in Google results

### Video Embedding
Simply paste any YouTube or Vimeo URL in the **YouTube / Vimeo URL** field:
- `https://www.youtube.com/watch?v=XXXXXXXXXXX`
- `https://vimeo.com/XXXXXXXXX`

The video will automatically embed beautifully in your post.

---

## ❓ Common Questions

**Q: How do I change my author name?**  
A: In each new post, update the "Author Name" field in the CMS.

**Q: Can I change the site's navigation links?**  
A: Edit `components/Header.js` and `components/Footer.js`.

**Q: How do I add a new category?**  
A: Edit `admin/config.yml` and `pages/category/[category].js` — or contact your developer.

**Q: Where do uploaded images go?**  
A: Automatically to `public/images/uploads/` in your GitHub repository.

**Q: How long after publishing does my post appear?**  
A: About 1-3 minutes (Netlify rebuild time).

---

## 🆘 Need Help?

If anything isn't working:
1. Check Netlify's **Deploy logs** for error messages
2. Make sure Netlify Identity and Git Gateway are both enabled
3. Ensure you've accepted your invitation email

---

*Built with Next.js, Decap CMS, and deployed on Netlify.*
*Zero monthly cost. Professional results.*
