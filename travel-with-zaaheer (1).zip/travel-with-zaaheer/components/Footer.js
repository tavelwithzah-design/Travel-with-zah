import Link from 'next/link'
import styles from './Footer.module.css'

export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className={styles.footer}>
      <div className={styles.topBar}></div>
      <div className={styles.inner}>
        {/* Brand */}
        <div className={styles.brand}>
          <span className={styles.brandSub}>Travel With</span>
          <span className={styles.brandName}>Zaaheer</span>
          <div className={styles.goldLine}></div>
          <p className={styles.brandTagline}>
            Curating extraordinary journeys<br />across the world's finest destinations.
          </p>
        </div>

        {/* Navigation Columns */}
        <div className={styles.columns}>
          <div className={styles.column}>
            <h4 className={styles.colTitle}>Explore</h4>
            <ul className={styles.colList}>
              <li><Link href="/category/destinations">Destinations</Link></li>
              <li><Link href="/category/luxury-stays">Luxury Stays</Link></li>
              <li><Link href="/category/adventure">Adventure</Link></li>
              <li><Link href="/category/culture-food">Culture & Food</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h4 className={styles.colTitle}>Guides</h4>
            <ul className={styles.colList}>
              <li><Link href="/category/travel-tips">Travel Tips</Link></li>
              <li><Link href="/category/photography">Photography</Link></li>
              <li><Link href="/blog">All Posts</Link></li>
            </ul>
          </div>
        </div>

        {/* Social / Newsletter */}
        <div className={styles.social}>
          <h4 className={styles.colTitle}>Follow the Journey</h4>
          <div className={styles.socialLinks}>
            <a href="#" className={styles.socialLink} target="_blank" rel="noopener noreferrer">Instagram</a>
            <a href="#" className={styles.socialLink} target="_blank" rel="noopener noreferrer">YouTube</a>
            <a href="#" className={styles.socialLink} target="_blank" rel="noopener noreferrer">Pinterest</a>
          </div>
        </div>
      </div>

      <div className={styles.bottom}>
        <span>© {currentYear} Travel With Zaaheer. All rights reserved.</span>
        <span className={styles.dot}>·</span>
        <span>Crafted with intention</span>
      </div>
    </footer>
  )
}
