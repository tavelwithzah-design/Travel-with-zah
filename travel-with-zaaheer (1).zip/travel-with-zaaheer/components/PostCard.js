import Link from 'next/link'
import { formatDate, formatCategoryName } from '../lib/posts'
import styles from './PostCard.module.css'

export default function PostCard({ post, featured = false, size = 'normal' }) {
  const { slug, title, excerpt, featuredImage, featuredImageAlt, date, category, readTime, author } = post

  if (featured) {
    return (
      <article className={styles.featured}>
        <Link href={`/blog/${slug}`} className={styles.featuredImageLink} aria-label={title}>
          <div className={styles.featuredImageWrap}>
            {featuredImage ? (
              <img
                src={featuredImage}
                alt={featuredImageAlt || title}
                className={styles.featuredImg}
              />
            ) : (
              <div className={styles.imagePlaceholder}>
                <span>✦</span>
              </div>
            )}
            <div className={styles.featuredOverlay}></div>
          </div>
        </Link>
        <div className={styles.featuredContent}>
          <div className={styles.meta}>
            {category && (
              <Link href={`/category/${category}`} className={styles.categoryBadge}>
                {formatCategoryName(category)}
              </Link>
            )}
            <span className={styles.metaDivider}>·</span>
            <span className={styles.readTime}>{readTime} min read</span>
          </div>
          <Link href={`/blog/${slug}`} className={styles.titleLink}>
            <h2 className={styles.featuredTitle}>{title}</h2>
          </Link>
          <div className={styles.goldLine}></div>
          {excerpt && (
            <p className={styles.featuredExcerpt}>{excerpt}</p>
          )}
          <div className={styles.footer}>
            <span className={styles.authorDate}>By {author || 'Zaaheer'} · {formatDate(date)}</span>
            <Link href={`/blog/${slug}`} className={styles.readMore}>
              Read Story <span className={styles.arrow}>→</span>
            </Link>
          </div>
        </div>
      </article>
    )
  }

  // Standard card
  return (
    <article className={`${styles.card} ${size === 'large' ? styles.cardLarge : ''}`}>
      <Link href={`/blog/${slug}`} className={styles.cardImageLink} aria-label={title}>
        <div className={styles.cardImageWrap}>
          {featuredImage ? (
            <img
              src={featuredImage}
              alt={featuredImageAlt || title}
              className={styles.cardImg}
            />
          ) : (
            <div className={styles.imagePlaceholder}>
              <span>✦</span>
            </div>
          )}
        </div>
      </Link>
      <div className={styles.cardContent}>
        <div className={styles.meta}>
          {category && (
            <Link href={`/category/${category}`} className={styles.categoryLabel}>
              {formatCategoryName(category)}
            </Link>
          )}
        </div>
        <Link href={`/blog/${slug}`} className={styles.titleLink}>
          <h3 className={styles.cardTitle}>{title}</h3>
        </Link>
        {excerpt && size === 'large' && (
          <p className={styles.cardExcerpt}>{excerpt}</p>
        )}
        <div className={styles.cardMeta}>
          <span className={styles.metaDate}>{formatDate(date)}</span>
          <span className={styles.metaDot}></span>
          <span className={styles.readTime}>{readTime} min read</span>
        </div>
      </div>
    </article>
  )
}
