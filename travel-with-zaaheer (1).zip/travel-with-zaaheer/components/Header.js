import Link from 'next/link'
import { useState, useEffect } from 'react'
import styles from './Header.module.css'

export default function Header() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`}>
      <div className={styles.inner}>
        {/* Left Nav */}
        <nav className={styles.navLeft} aria-label="Primary navigation left">
          <Link href="/category/destinations" className={styles.navLink}>Destinations</Link>
          <Link href="/category/luxury-stays" className={styles.navLink}>Luxury Stays</Link>
          <Link href="/category/travel-tips" className={styles.navLink}>Travel Tips</Link>
        </nav>

        {/* Logo / Brand */}
        <Link href="/" className={styles.logo}>
          <span className={styles.logoTop}>Travel With</span>
          <span className={styles.logoMain}>Zaaheer</span>
        </Link>

        {/* Right Nav */}
        <nav className={styles.navRight} aria-label="Primary navigation right">
          <Link href="/category/adventure" className={styles.navLink}>Adventure</Link>
          <Link href="/category/culture-food" className={styles.navLink}>Culture</Link>
          <Link href="/blog" className={styles.navLink}>All Posts</Link>
        </nav>

        {/* Mobile Toggle */}
        <button
          className={styles.menuToggle}
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle navigation"
        >
          <span className={menuOpen ? styles.barOpen : styles.bar}></span>
          <span className={menuOpen ? styles.barOpen : styles.bar}></span>
          <span className={menuOpen ? styles.barOpen : styles.bar}></span>
        </button>
      </div>

      {/* Gold accent line */}
      <div className={styles.goldBar}></div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className={styles.mobileMenu}>
          <Link href="/" className={styles.mobileLink} onClick={() => setMenuOpen(false)}>Home</Link>
          <Link href="/category/destinations" className={styles.mobileLink} onClick={() => setMenuOpen(false)}>Destinations</Link>
          <Link href="/category/luxury-stays" className={styles.mobileLink} onClick={() => setMenuOpen(false)}>Luxury Stays</Link>
          <Link href="/category/travel-tips" className={styles.mobileLink} onClick={() => setMenuOpen(false)}>Travel Tips</Link>
          <Link href="/category/adventure" className={styles.mobileLink} onClick={() => setMenuOpen(false)}>Adventure</Link>
          <Link href="/category/culture-food" className={styles.mobileLink} onClick={() => setMenuOpen(false)}>Culture & Food</Link>
          <Link href="/blog" className={styles.mobileLink} onClick={() => setMenuOpen(false)}>All Posts</Link>
        </div>
      )}
    </header>
  )
}
