import Head from 'next/head'

export default function SEO({
  title,
  description,
  image,
  url,
  type = 'website',
  publishedTime,
  author,
}) {
  const siteName = 'Travel With Zaaheer'
  const siteUrl = 'https://travelwithzaaheer.com'
  const defaultDescription = 'Luxury travel stories, destination guides, and cinematic journeys from around the world.'
  const defaultImage = `${siteUrl}/images/og-default.jpg`

  const fullTitle = title ? `${title} | ${siteName}` : siteName
  const metaDesc = description || defaultDescription
  const metaImage = image || defaultImage
  const metaUrl = url ? `${siteUrl}${url}` : siteUrl

  return (
    <Head>
      {/* Primary */}
      <title>{fullTitle}</title>
      <meta name="description" content={metaDesc} />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta name="robots" content="index, follow" />
      <link rel="canonical" href={metaUrl} />

      {/* Favicon */}
      <link rel="icon" href="/favicon.ico" />
      <link rel="apple-touch-icon" href="/apple-touch-icon.png" />

      {/* Open Graph */}
      <meta property="og:type" content={type} />
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={metaDesc} />
      <meta property="og:image" content={metaImage} />
      <meta property="og:image:alt" content={title || siteName} />
      <meta property="og:url" content={metaUrl} />
      <meta property="og:site_name" content={siteName} />
      <meta property="og:locale" content="en_US" />

      {/* Twitter Card */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={metaDesc} />
      <meta name="twitter:image" content={metaImage} />

      {/* Article specific */}
      {type === 'article' && publishedTime && (
        <meta property="article:published_time" content={publishedTime} />
      )}
      {type === 'article' && author && (
        <meta property="article:author" content={author} />
      )}

      {/* Schema.org JSON-LD */}
      {type === 'article' && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'Article',
              headline: title,
              description: metaDesc,
              image: metaImage,
              datePublished: publishedTime,
              author: {
                '@type': 'Person',
                name: author || 'Zaaheer',
              },
              publisher: {
                '@type': 'Organization',
                name: siteName,
                url: siteUrl,
              },
              mainEntityOfPage: {
                '@type': 'WebPage',
                '@id': metaUrl,
              },
            }),
          }}
        />
      )}
    </Head>
  )
}
